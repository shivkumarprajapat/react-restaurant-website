import React from 'react'

function Footer() {
    return (
        <div className="copyrightText">
            <p>Copyright by 2021 <a href="//#endregion">Shiv Kumar Prajapat</a></p>
        </div>
    )
}

export default Footer
